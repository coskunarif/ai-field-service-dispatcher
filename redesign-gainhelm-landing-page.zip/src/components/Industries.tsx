import { motion } from 'framer-motion';
import { Thermometer, Droplets, TreePine, ArrowRight } from 'lucide-react';

const industries = [
  {
    icon: Thermometer,
    name: 'HVAC Teams',
    description: 'Keep service calls organized, reduce missed handoffs, and move emergency work faster with real-time dispatch updates.',
    stat: '40% faster emergency response',
    color: 'bg-orange-50 text-orange-600 border-orange-200',
    imageColor: 'bg-gradient-to-br from-orange-100 to-amber-50',
  },
  {
    icon: Droplets,
    name: 'Plumbing Companies',
    description: 'Track new jobs, schedule arrivals, and keep the office and technicians on the same page without constant phone calls.',
    stat: '60% fewer missed appointments',
    color: 'bg-blue-50 text-blue-600 border-blue-200',
    imageColor: 'bg-gradient-to-br from-blue-100 to-sky-50',
  },
  {
    icon: TreePine,
    name: 'Landscaping Crews',
    description: 'Coordinate recurring work and day-of changes without losing visibility across the schedule or crew assignments.',
    stat: '3x more jobs per day',
    color: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    imageColor: 'bg-gradient-to-br from-emerald-100 to-green-50',
  },
];

export default function Industries() {
  return (
    <section id="industries" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-brand-50 border border-brand-200 text-brand-700 text-sm font-medium mb-4">
            Industries
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Built for the teams that{' '}
            <span className="gradient-text">keep things running</span>
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Whether you fix AC units, unclog drains, or maintain lawns — Gainhelm is designed for your workflow.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {industries.map((industry, i) => (
            <motion.div
              key={industry.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group bg-white rounded-2xl overflow-hidden border border-slate-200/80 hover:border-brand-300 hover:shadow-xl hover:shadow-brand-500/5 transition-all duration-300"
            >
              <div className={`h-40 ${industry.imageColor} flex items-center justify-center relative overflow-hidden`}>
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute top-4 left-4 w-20 h-20 rounded-full bg-white/40" />
                  <div className="absolute bottom-4 right-4 w-32 h-32 rounded-full bg-white/30" />
                </div>
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center border-2 bg-white shadow-lg ${industry.color}`}>
                  <industry.icon className="w-8 h-8" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-2">{industry.name}</h3>
                <p className="text-sm text-slate-600 leading-relaxed mb-4">{industry.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-brand-600 bg-brand-50 px-3 py-1.5 rounded-full border border-brand-200">
                    {industry.stat}
                  </span>
                  <span className="text-sm font-medium text-slate-400 group-hover:text-brand-600 transition-colors flex items-center gap-1">
                    Learn more <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
