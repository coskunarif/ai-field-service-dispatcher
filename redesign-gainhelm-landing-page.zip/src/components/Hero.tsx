import { motion } from 'framer-motion';
import { ArrowRight, Zap, Clock, Shield } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-slate-50">
      {/* Background grid */}
      <div className="absolute inset-0 hero-grid opacity-60" />
      
      {/* Decorative blobs */}
      <div className="absolute top-20 right-0 w-[500px] h-[500px] bg-brand-200/30 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-amber-100/40 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50 border border-brand-200/60 text-brand-700 text-sm font-medium"
            >
              <Zap className="w-4 h-4" />
              Early access now open
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.1] tracking-tight"
            >
              AI dispatch software{' '}
              <span className="gradient-text">built for field service teams</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg sm:text-xl text-slate-600 leading-relaxed max-w-xl"
            >
              Assign work faster, cut down on phone tag, and keep schedules clear 
              without spreadsheets or messy handoffs. Built for HVAC, plumbing, and landscaping teams.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <a
                href="#waitlist"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-xl shadow-xl shadow-brand-500/25 transition-all hover:shadow-brand-500/40 hover:-translate-y-0.5"
              >
                Join the waitlist
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#how-it-works"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white hover:bg-slate-50 text-slate-700 font-semibold rounded-xl border border-slate-200 transition-all hover:-translate-y-0.5"
              >
                See how it works
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex items-center gap-6 pt-4"
            >
              {[
                { icon: Clock, text: 'Save 5+ hrs/week' },
                { icon: Shield, text: 'No credit card required' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-2 text-sm text-slate-500">
                  <Icon className="w-4 h-4 text-brand-500" />
                  {text}
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right - Dispatch board mockup */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative"
          >
            <div className="relative bg-white rounded-2xl shadow-2xl shadow-slate-900/10 border border-slate-200/80 overflow-hidden">
              {/* Browser chrome */}
              <div className="flex items-center gap-2 px-4 py-3 bg-slate-50 border-b border-slate-200/80">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-amber-400" />
                  <div className="w-3 h-3 rounded-full bg-emerald-400" />
                </div>
                <div className="flex-1 mx-4">
                  <div className="bg-white rounded-md px-3 py-1.5 text-xs text-slate-400 border border-slate-200 text-center">
                    gainhelm.com/dispatch
                  </div>
                </div>
              </div>

              {/* Board content */}
              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">Today's Dispatch</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Monday, June 16 — 8 jobs</p>
                  </div>
                  <div className="flex gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 text-xs font-medium border border-emerald-200">3 Active</span>
                    <span className="px-2.5 py-1 rounded-md bg-amber-50 text-amber-700 text-xs font-medium border border-amber-200">2 Pending</span>
                  </div>
                </div>

                {/* Job cards */}
                <div className="space-y-3">
                  {[
                    {
                      title: 'Emergency AC repair',
                      location: 'Northside · 124 Oak St',
                      tech: 'Unassigned',
                      status: 'Needs assignment',
                      statusColor: 'bg-amber-50 text-amber-700 border-amber-200',
                      priority: true,
                    },
                    {
                      title: 'Kitchen leak follow-up',
                      location: 'Westside · 789 Pine Ave',
                      tech: 'Maria R.',
                      status: 'Scheduled',
                      statusColor: 'bg-blue-50 text-blue-700 border-blue-200',
                      priority: false,
                    },
                    {
                      title: 'HVAC maintenance',
                      location: 'Downtown · 456 Elm Blvd',
                      tech: 'James T.',
                      status: 'In progress',
                      statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                      priority: false,
                    },
                    {
                      title: 'Landscaping maintenance',
                      location: 'Eastside · 321 Maple Dr',
                      tech: 'Crew B',
                      status: 'Ready to go',
                      statusColor: 'bg-slate-50 text-slate-700 border-slate-200',
                      priority: false,
                    },
                  ].map((job, i) => (
                    <motion.div
                      key={job.title}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 + i * 0.1 }}
                      className={`p-3.5 rounded-xl border transition-all hover:shadow-md cursor-pointer ${
                        job.priority
                          ? 'bg-amber-50/50 border-amber-200/60'
                          : 'bg-white border-slate-200/80 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold text-slate-900 truncate">{job.title}</p>
                            {job.priority && (
                              <span className="shrink-0 px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700 uppercase tracking-wider">
                                Urgent
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 mt-1">{job.location}</p>
                        </div>
                        <span className={`shrink-0 px-2 py-1 rounded-md text-[11px] font-medium border ${job.statusColor}`}>
                          {job.status}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-2.5">
                        <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center">
                          <span className="text-[9px] font-bold text-slate-600">
                            {job.tech.charAt(0)}
                          </span>
                        </div>
                        <span className="text-xs text-slate-600">{job.tech}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.2 }}
              className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-xl shadow-slate-900/10 border border-slate-200 p-4 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <Zap className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">AI Assigned</p>
                <p className="text-xs text-slate-500">Matched to best tech</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
