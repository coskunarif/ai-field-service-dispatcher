import { motion } from 'framer-motion';
import { ClipboardList, UserCheck, CheckCircle2 } from 'lucide-react';

const steps = [
  {
    number: '01',
    icon: ClipboardList,
    title: 'Add the job',
    description: 'Capture the customer request, location, and work details in seconds. AI extracts key info so you don\'t have to type everything.',
    color: 'bg-amber-50 text-amber-600',
  },
  {
    number: '02',
    icon: UserCheck,
    title: 'Assign the right technician',
    description: 'Our AI matches the job to the best available tech based on skills, proximity, and workload. One click to confirm.',
    color: 'bg-blue-50 text-blue-600',
  },
  {
    number: '03',
    icon: CheckCircle2,
    title: 'Follow through to completion',
    description: 'Track progress in real time. Techs update status from the field, customers get notified, and nothing falls through the cracks.',
    color: 'bg-emerald-50 text-emerald-600',
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-brand-50 border border-brand-200 text-brand-700 text-sm font-medium mb-4">
            How it works
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Three steps to a{' '}
            <span className="gradient-text">cleaner dispatch flow</span>
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Simple enough to explain in seconds, structured enough to transform how your team operates.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connector line */}
          <div className="hidden md:block absolute top-24 left-[16.67%] right-[16.67%] h-0.5 bg-gradient-to-r from-amber-200 via-blue-200 to-emerald-200" />

          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative text-center"
            >
              <div className="relative z-10 inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white border-2 border-slate-100 shadow-lg mb-6">
                <step.icon className={`w-7 h-7 ${step.color.split(' ')[1]}`} />
              </div>
              <div className="inline-block px-3 py-1 rounded-full bg-slate-100 text-slate-500 text-xs font-bold mb-4">
                Step {step.number}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{step.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed max-w-xs mx-auto">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
