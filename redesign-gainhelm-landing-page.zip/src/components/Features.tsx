import { motion } from 'framer-motion';
import { Zap, Calendar, Users, MessageSquare, MapPin, BarChart3 } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'AI-Powered Dispatch',
    description: 'Automatically assign jobs to the right technician based on skills, location, and availability. No more guesswork.',
    color: 'bg-amber-50 text-amber-600 border-amber-200',
  },
  {
    icon: Calendar,
    title: 'Smart Scheduling',
    description: 'One shared calendar that keeps office and field aligned. See every job, every tech, every route in real time.',
    color: 'bg-blue-50 text-blue-600 border-blue-200',
  },
  {
    icon: Users,
    title: 'Team Coordination',
    description: 'Replace scattered text threads with structured handoffs. Everyone knows what\'s next without the back-and-forth.',
    color: 'bg-emerald-50 text-emerald-600 border-emerald-200',
  },
  {
    icon: MessageSquare,
    title: 'Customer Updates',
    description: 'Keep customers in the loop with automated status updates. Reduce "where\'s my tech?" calls by 80%.',
    color: 'bg-violet-50 text-violet-600 border-violet-200',
  },
  {
    icon: MapPin,
    title: 'Route Optimization',
    description: 'Cut drive time with intelligent routing. Get technicians to jobs faster and fit more calls into each day.',
    color: 'bg-rose-50 text-rose-600 border-rose-200',
  },
  {
    icon: BarChart3,
    title: 'Performance Insights',
    description: 'Track completion rates, response times, and team productivity. Make data-driven decisions to grow your business.',
    color: 'bg-cyan-50 text-cyan-600 border-cyan-200',
  },
];

export default function Features() {
  return (
    <section id="features" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-brand-50 border border-brand-200 text-brand-700 text-sm font-medium mb-4">
            Features
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Everything you need to run dispatch{' '}
            <span className="gradient-text">without the chaos</span>
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Built from the ground up for small field service teams who need modern tools 
            without enterprise complexity.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="group bg-white rounded-2xl p-6 border border-slate-200/80 hover:border-brand-300 hover:shadow-xl hover:shadow-brand-500/5 transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center border mb-4 ${feature.color}`}>
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
